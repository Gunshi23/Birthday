import React, { useState } from 'react';
import data from './data'; 

const App = () => {
  const [people, setPeople] = useState(data);

  const clearList = () => {
    setPeople([]);
  };

  
  const Person = ({ name, age, image }) => {
    return (
      <article className="person" style={{ display: 'flex', alignItems: 'center', marginBottom: '10px' }}>
        <img
          src={image}
          alt={name}
          style={{ width: '50px', height: '50px', borderRadius: '50%', marginRight: '10px' }}
        />
        <div>
          <h4>{name}</h4>
          <p>{age} years</p>
        </div>
      </article>
    );
  };

  
  const List = ({ people }) => {
    return (
      <>
        {people.map((person) => (
          <Person key={person.id} {...person} />
        ))}
      </>
    );
  };

  return (
    <main>
      <section className="container">
        <h3>{people.length} birthdays today</h3>
        <List people={people} />
        <button onClick={clearList}>Clear All</button>
      </section>
    </main>
  );
};

export default App;